# In the name of God

robot_id = 'your robot id'
password = 'pass'
