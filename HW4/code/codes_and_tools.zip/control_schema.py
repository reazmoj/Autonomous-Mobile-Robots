# In the name of God

import numpy as np
from tools.sim_tools import SimConnector
from tools.viewer import LiveViewer
import time
from tools.credentials import robot_id, password

sim = SimConnector(robot_id, password)
viewer = LiveViewer(sim, 3)
viewer.start_view()

sim.reset()

data_log = np.zeros([1e5, 2])
cntr = 0

# your initializations here

control_rate = 20.0  # Hz
control_period = 1.0/control_rate

while True:
    state = sim.get_drone_state()
    height = -state['position'][2]  # is needed for control
    data_log[cntr, 0] = height  # for logging and plotting purpose

    # your control logic here
    # calculate motor_pwms
    # motor_pwms
    data_log[cntr, 1] = motor_pwms

    cntr += 1
    sim.send_motor_command(motor_pwms, motor_pwms, motor_pwms, motor_pwms, control_period)
    time.sleep(control_period)

    # termination criteria
    if termination criteria satisfied:
        break

data_log = data_log[:cntr, :]  # remove unnecessary memory allocs

# plottings here using data_log
